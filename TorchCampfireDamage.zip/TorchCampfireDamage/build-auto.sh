#!/bin/bash
# 一键构建脚本 - 自动下载依赖并构建

set -e

echo "========================================"
echo "Torch Campfire Damage - 一键构建脚本"
echo "========================================"
echo ""

# 检查 Java
if ! command -v java &> /dev/null; then
    echo "错误: 未找到 Java，请先安装 Java 21"
    exit 1
fi

JAVA_VERSION=$(java -version 2>&1 | head -n 1 | cut -d'"' -f2 | cut -d'.' -f1)
if [ "$JAVA_VERSION" -lt 21 ]; then
    echo "错误: 需要 Java 21 或更高版本，当前版本: $JAVA_VERSION"
    exit 1
fi

echo "✓ Java 版本检查通过"

# 创建构建目录
BUILD_DIR="$(pwd)/build_auto"
mkdir -p "$BUILD_DIR"
cd "$BUILD_DIR"

# 下载 NeoForge MDK
echo ""
echo "下载 NeoForge MDK..."
if [ ! -f "neoforge-21.1.72-mdk.zip" ]; then
    wget -q --show-progress "https://maven.neoforged.net/releases/net/neoforged/neoforge/21.1.72/neoforge-21.1.72-mdk.zip" -O neoforge-21.1.72-mdk.zip || {
        echo "下载失败，尝试使用 curl..."
        curl -L "https://maven.neoforged.net/releases/net/neoforged/neoforge/21.1.72/neoforge-21.1.72-mdk.zip" -o neoforge-21.1.72-mdk.zip
    }
fi

echo "✓ NeoForge MDK 下载完成"

# 解压
echo ""
echo "解压 MDK..."
unzip -q neoforge-21.1.72-mdk.zip -d mdk
cd mdk

echo "✓ MDK 解压完成"

# 复制我们的源代码
echo ""
echo "复制源代码..."
cp -r ../../src/* src/main/

echo "✓ 源代码复制完成"

# 构建
echo ""
echo "开始构建..."
chmod +x gradlew
./gradlew build --no-daemon

# 复制构建结果
echo ""
echo "复制构建结果..."
cp build/libs/*.jar ../../../

echo ""
echo "========================================"
echo "构建完成！"
echo "JAR 文件位置: $(ls ../../../torchcampfiredamage-*.jar 2>/dev/null || echo '未找到')"
echo "========================================"