@echo off
REM 构建脚本 for Windows

echo ========================================
echo Torch Campfire Damage - 构建脚本
echo ========================================
echo.

REM 检查 Java 版本
echo 检查 Java 版本...
java -version 2>&1 | findstr /C:"version"

REM 检查 Gradle
if exist "gradlew.bat" (
    echo 使用 Gradle Wrapper...
    gradlew.bat build
) else (
    where gradle >nul 2>&1
    if %errorlevel% == 0 (
        echo 使用系统 Gradle...
        gradle build
    ) else (
        echo 错误: 未找到 Gradle
        echo 请安装 Gradle 或使用 Gradle Wrapper
        exit /b 1
    )
)

echo.
echo ========================================
echo 构建完成！
echo 输出文件: build/libs/
echo ========================================
pause