#!/bin/bash
# 构建脚本 for Linux/Mac

echo "========================================"
echo "Torch Campfire Damage - 构建脚本"
echo "========================================"
echo ""

# 检查 Java 版本
echo "检查 Java 版本..."
java -version 2>&1 | head -n 1

# 检查 Gradle
if [ -f "./gradlew" ]; then
    echo "使用 Gradle Wrapper..."
    chmod +x ./gradlew
    ./gradlew build
elif command -v gradle &> /dev/null; then
    echo "使用系统 Gradle..."
    gradle build
else
    echo "错误: 未找到 Gradle"
    echo "请安装 Gradle 或使用 Gradle Wrapper"
    exit 1
fi

echo ""
echo "========================================"
echo "构建完成！"
echo "输出文件: build/libs/"
echo "========================================"